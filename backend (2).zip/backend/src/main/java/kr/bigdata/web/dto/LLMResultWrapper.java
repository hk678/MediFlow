package kr.bigdata.web.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LLMResultWrapper {
	private LLMResult result;

}
