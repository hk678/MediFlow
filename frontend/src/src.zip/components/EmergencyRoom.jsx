import React, { useState } from 'react';
import { Search, User, Users, Bed, AlertCircle, AlertTriangle } from 'lucide-react';
import '../css/emergencyroom.css';


const EmergencyRoomDashboard = () => {
  const [searchTerm, setSearchTerm] = useState('');

  // 병상 데이터 - 위치별로 구성
  const bedData = {
    // 상단 구역
    topSection: [
      { id: 'A1', status: 'emergency', patient: '김민수\n01/응급실', color: 'green' },
      { id: 'A2', status: 'warning', patient: '환자명\n01/응급실', color: 'yellow' },
      { id: 'A3', status: 'danger', patient: '환자명\n01/응급실', color: 'red' },
      { id: 'A4', status: 'empty', patient: '', color: 'gray' },
      { id: 'A5', status: 'emergency', patient: '김민수\n01/응급실', color: 'green' },
      { id: 'A6', status: 'warning', patient: '환자명\n01/응급실', color: 'yellow' },
      { id: 'A7', status: 'emergency', patient: '김민수\n01/응급실', color: 'orange' }
    ],
    // 중앙 구역
    middleSection: [
      { id: 'B1', status: 'danger', patient: '김민수\n01/응급실', color: 'red' },
      { id: 'B2', status: 'warning', patient: '입원대기\n1/고체', color: 'yellow' },
      { id: 'B3', status: 'warning', patient: '퇴원준비\n01/고체', color: 'yellow' },
      { id: 'B4', status: 'warning', patient: '퇴원준비\n01/고체', color: 'yellow' },
      { id: 'B5', status: 'danger', patient: '김민수\n01/응급실', color: 'red' },
      { id: 'B6', status: 'warning', patient: '입원예정\n01/고체', color: 'yellow' },
      { id: 'B7', status: 'warning', patient: '입원대기\n01/고체', color: 'yellow' }
    ],
    // 하단 구역
    bottomSection: [
      { id: 'C1', status: 'emergency', patient: '김민수\n01/응급실', color: 'green' },
      { id: 'C2', status: 'empty', patient: '', color: 'gray' },
      { id: 'C3', status: 'danger', patient: '김민수\n01/응급실', color: 'red' },
      { id: 'C4', status: 'emergency', patient: '김민수\n01/응급실', color: 'yellow' },
      { id: 'C5', status: 'empty', patient: '', color: 'gray' },
      { id: 'C6', status: 'warning', patient: '환자명\n01/응급실', color: 'yellow' },
      { id: 'C7', status: 'warning', patient: '환자명\n01/응급실', color: 'red' },
      { id: 'C8', status: 'warning', patient: '환자명\n01/응급실', color: 'green' }
    ]
  };

  const getBedClassName = (color, status) => {
    const baseClass = 'bed-card';
    if (status === 'empty') return `${baseClass} bed-empty`;
    
    switch(color) {
      case 'red': return `${baseClass} bed-danger`;
      case 'yellow': return `${baseClass} bed-warning`;
      case 'green': return `${baseClass} bed-success`;
      case 'orange': return `${baseClass} bed-orange`;
      default: return `${baseClass} bed-empty`;
    }
  };

  const BedCard = ({ bed }) => (
    <div className={getBedClassName(bed.color, bed.status)}>
      {bed.patient && (
        <div className="bed-content">
          {bed.patient.split('\n').map((line, index) => (
            <div key={index} className="bed-text">
              {line}
            </div>
          ))}
        </div>
      )}
    </div>
  );

  return (
    <div className="emergency-dashboard">
      <div className="dashboard-content">
        {/* Header */}
        <div className="header">
          <div className="header-content">
            <div className="header-left">
              <div className="logo">
                <span className="logo-text">의료</span>
              </div>
              <div className="search-container">
                <Search className="search-icon" />
                <input
                  type="text"
                  placeholder="Search"
                  className="search-input"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
            <div className="user-info">
              <User className="user-icon" />
              <span className="user-name">Your Name</span>
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="stats-grid">
          <div className="stat-card">
            <div className="stat-content">
              <Users className="stat-icon blue" />
              <div>
                <div className="stat-number blue">29</div>
              </div>
            </div>
          </div>
          
          <div className="stat-card">
            <div className="stat-content">
              <Bed className="stat-icon blue" />
              <div>
                <div className="stat-number blue">19/28</div>
              </div>
            </div>
          </div>
          
          <div className="stat-card">
            <div className="stat-content">
              <AlertCircle className="stat-icon red" />
              <div>
                <div className="stat-label">위험 환자</div>
                <div className="stat-number red">6</div>
              </div>
            </div>
          </div>
          
          <div className="stat-card">
            <div className="stat-content">
              <AlertTriangle className="stat-icon yellow" />
              <div>
                <div className="stat-label">주의 환자</div>
                <div className="stat-number yellow">7</div>
              </div>
            </div>
          </div>
        </div>

        {/* Toggle Switch */}
        <div className="toggle-container">
          <div className="toggle-wrapper">
            <span className="toggle-label">병상 리스트 보기</span>
            <div className="toggle-switch">
              <div className="toggle-slider"></div>
            </div>
          </div>
        </div>

        {/* Emergency Room Layout */}
        <div className="emergency-room-container">
          <div className="room-layout">
            {/* Top Section */}
            <div className="bed-section top-section">
              <div className="bed-row">
                {bedData.topSection.slice(0, 1).map(bed => (
                  <BedCard key={bed.id} bed={bed} />
                ))}
                <div className="bed-spacer"></div>
                {bedData.topSection.slice(1, 3).map(bed => (
                  <BedCard key={bed.id} bed={bed} />
                ))}
                <div className="bed-spacer"></div>
                {bedData.topSection.slice(3, 4).map(bed => (
                  <BedCard key={bed.id} bed={bed} />
                ))}
                <div className="bed-spacer"></div>
                {bedData.topSection.slice(4, 6).map(bed => (
                  <BedCard key={bed.id} bed={bed} />
                ))}
                <div className="bed-spacer"></div>
                {bedData.topSection.slice(6, 7).map(bed => (
                  <BedCard key={bed.id} bed={bed} />
                ))}
              </div>
            </div>

            {/* Middle Section */}
            <div className="bed-section middle-section">
              <div className="bed-row">
                {bedData.middleSection.slice(0, 1).map(bed => (
                  <BedCard key={bed.id} bed={bed} />
                ))}
                <div className="bed-spacer"></div>
                <div className="bed-spacer"></div>
                <div className="bed-spacer"></div>
                {bedData.middleSection.slice(1, 3).map(bed => (
                  <BedCard key={bed.id} bed={bed} />
                ))}
                <div className="bed-spacer"></div>
                {bedData.middleSection.slice(3, 5).map(bed => (
                  <BedCard key={bed.id} bed={bed} />
                ))}
                <div className="bed-spacer"></div>
                {bedData.middleSection.slice(5, 7).map(bed => (
                  <BedCard key={bed.id} bed={bed} />
                ))}
              </div>
            </div>

            {/* Bottom Section */}
            <div className="bed-section bottom-section">
              <div className="bed-row">
                {bedData.bottomSection.slice(0, 1).map(bed => (
                  <BedCard key={bed.id} bed={bed} />
                ))}
                <div className="bed-spacer"></div>
                {bedData.bottomSection.slice(1, 2).map(bed => (
                  <BedCard key={bed.id} bed={bed} />
                ))}
                <div className="bed-spacer"></div>
                {bedData.bottomSection.slice(2, 6).map(bed => (
                  <BedCard key={bed.id} bed={bed} />
                ))}
                <div className="bed-spacer"></div>
                {bedData.bottomSection.slice(6, 8).map(bed => (
                  <BedCard key={bed.id} bed={bed} />
                ))}
              </div>
            </div>

            {/* Nurse Station */}
            <div className="nurse-station">
              <div className="nurse-station-text">Nurse Station</div>
            </div>

            {/* Entrance */}
            <div className="entrance">
              <div className="entrance-text">Entrance</div>
            </div>
          </div>
        </div>
      </div>


    </div>
  );
};

export default EmergencyRoomDashboard;