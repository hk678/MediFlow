import React from "react";
import { X } from "lucide-react";
import '../css/userupdate.css';

export default function UserUpdate() {
  // 사용자 정보 (읽기 전용)
  const userData = {
    id: '',
    password: '',
    name: '',
    position: ''
  };

  const handleSave = () => {
    console.log('저장 버튼 클릭');
  };

  const handleDelete = () => {
    console.log('삭제 버튼 클릭');
  };

  const handleClose = () => {
    console.log('모달 닫기');
  };

  return (
    <div className="user-info-modal">
      <div className="user-info-content">
        {/* 헤더 */}
        <div className="user-info-header">
          <h2 className="user-info-title">사용자 정보</h2>
          <button className="close-button" onClick={handleClose}>
            <X className="close-icon" />
          </button>
        </div>

        {/* 정보 표시 영역 */}
        <div className="user-form">
          {/* ID */}
          <div className="input-group">
            <label className="input-label">ID</label>
            <span className="user-data">{userData.id}</span>
          </div>

          {/* PW */}
          <div className="input-group">
            <label className="input-label">PW</label>
            <span className="user-data">{userData.password}</span>
          </div>

          {/* Name */}
          <div className="input-group">
            <label className="input-label">Name</label>
            <span className="user-data">{userData.name}</span>
          </div>

          {/* Position */}
          <div className="input-group">
            <label className="input-label">Position</label>
            <div className="radio-group">
              <div className="radio-item">
                <input
                  type="radio"
                  id="doctor"
                  name="position"
                  value="의사"
                  className="radio-input"
                  checked={userData.position === '의사'}
                  disabled
                />
                <label htmlFor="doctor" className="radio-label">의사</label>
              </div>
              
              <div className="radio-item">
                <input
                  type="radio"
                  id="nurse"
                  name="position"
                  value="간호사"
                  className="radio-input"
                  checked={userData.position === '간호사'}
                  disabled
                />
                <label htmlFor="nurse" className="radio-label">간호사</label>
              </div>
              
              <div className="radio-item">
                <input
                  type="radio"
                  id="other"
                  name="position"
                  value="기타"
                  className="radio-input"
                  checked={userData.position === '기타'}
                  disabled
                />
                <label htmlFor="other" className="radio-label">기타</label>
              </div>
            </div>
          </div>
        </div>

        {/* 버튼 영역 */}
        <div className="button-container">
          <button 
            className="submit-button"
            onClick={handleSave}
          >
            저장
          </button>
          <button 
            className="delete-button"
            onClick={handleDelete}
          >
            삭제
          </button>
        </div>
      </div>
    </div>
  );
}