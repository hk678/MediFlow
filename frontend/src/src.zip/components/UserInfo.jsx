import React, { useState } from "react";
import { X } from "lucide-react";
import '../css/userinfo.css';

export default function UserInfo() {
  const [formData, setFormData] = useState({
    id: '',
    password: '',
    name: '',
    position: ''
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handlePositionChange = (e) => {
    setFormData(prev => ({
      ...prev,
      position: e.target.value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('사용자 정보:', formData);
  };

  const handleClose = () => {
    console.log('모달 닫기');
  };

  return (
    <div className="user-info-modal">
      <div className="user-info-content">
        <div className="user-info-header">
          <h2 className="user-info-title">사용자 정보</h2>
          <button className="close-button" onClick={handleClose}>
            <X className="close-icon" />
          </button>
        </div>

        <form className="user-form" onSubmit={handleSubmit}>
          <div className="input-group">
            <label className="input-label">ID</label>
            <input
              type="text"
              name="id"
              className="input-field"
              value={formData.id}
              onChange={handleInputChange}
              required
            />
          </div>

          <div className="input-group">
            <label className="input-label">PW</label>
            <input
              type="password"
              name="password"
              className="input-field"
              value={formData.password}
              onChange={handleInputChange}
              required
            />
          </div>

          <div className="input-group">
            <label className="input-label">Name</label>
            <input
              type="text"
              name="name"
              className="input-field"
              placeholder="이름을 입력해주세요"
              value={formData.name}
              onChange={handleInputChange}
              required
            />
          </div>

          <div className="input-group">
            <label className="input-label">Position</label>
            <div className="radio-group">
              <div className="radio-item">
                <input
                  type="radio"
                  id="doctor"
                  name="position"
                  value="의사"
                  className="radio-input"
                  checked={formData.position === '의사'}
                  onChange={handlePositionChange}
                />
                <label htmlFor="doctor" className="radio-label">의사</label>
              </div>
              
              <div className="radio-item">
                <input
                  type="radio"
                  id="nurse"
                  name="position"
                  value="간호사"
                  className="radio-input"
                  checked={formData.position === '간호사'}
                  onChange={handlePositionChange}
                />
                <label htmlFor="nurse" className="radio-label">간호사</label>
              </div>
              
              <div className="radio-item">
                <input
                  type="radio"
                  id="other"
                  name="position"
                  value="기타"
                  className="radio-input"
                  checked={formData.position === '기타'}
                  onChange={handlePositionChange}
                />
                <label htmlFor="other" className="radio-label">기타</label>
              </div>
            </div>
          </div>
        </form>

        <div className="button-container">
          <button 
            className="submit-button"
            onClick={handleSubmit}
          >
            저장
          </button>
        </div>
      </div>
    </div>
  );
}